# Mes Quiz

Appli Android qui regroupe mes quiz :

| Quiz | Contenu |
|---|---|
| 🧠 Culture G & acronymes | 38 acronymes, 98 questions de culture générale, chrono et combos |
| 🛡️ Matériel militaire | 69 équipements : fiches chiffrées, quiz, catalogue |
| Я Alphabet russe | 7 leçons, 33 lettres, prononciation (voix Android) |
| 🚩 Drapeaux & capitales | 97 pays : drapeaux, capitales, capitale → pays |
| 🔭 Sciences & espace | Espace, chimie, physique & unités, vivant |
| 💡 Marques & tech | Fondateurs, dates clés, origine des noms, pays d'origine |
| ⏳ Histoire & dates | Grandes dates, inventions, personnages |

## Installer l'appli sur le téléphone

À chaque `push` sur `main`, GitHub construit l'APK tout seul (onglet **Actions**, ~5 min)
et le publie dans **Releases**.

1. Sur le téléphone, ouvrir `https://github.com/<ton-compte>/mes-quiz/releases/latest`.
2. Toucher **MesQuiz.apk** pour le télécharger, puis l'ouvrir.
3. La première fois, Android demande d'autoriser l'installation depuis le navigateur : accepter.

Les versions suivantes s'installent par-dessus sans perdre la progression
(l'APK est toujours signé avec la même clé, `android/app/mesquiz.keystore`).

Pour la voix russe : *Paramètres → Système → Langues → Synthèse vocale* (moteur Google),
puis télécharger la voix russe si elle n'y est pas.

## Structure

```
www/                      l'appli web (ce que contient l'APK)
  index.html              écran d'accueil
  apps/culture|militaire|russe/index.html   les quiz existants (fichiers uniques)
  apps/quiz/index.html    moteur commun des nouveaux quiz (?t=drapeaux…)
  apps/quiz/data/*.js     les questions de chaque nouveau quiz
  shared/shell.js         barre « ‹ Mes Quiz », bouton retour Android, voix native
  shared/fonts/           polices embarquées (l'appli marche hors ligne)
android/                  projet Android généré par Capacitor
.github/workflows/android.yml   construction automatique de l'APK
```

## Ajouter un quiz

Créer `www/apps/quiz/data/<nom>.js` sur le modèle de `histoire.js`
(une question = `{k: catégorie, q, r: bonne réponse, w: [3 mauvaises ou plus], f: anecdote}`),
puis ajouter une tuile dans `APPS` de `www/index.html`.

## Tester sur PC

```
npm install
npm run serve        # puis ouvrir http://localhost:8080
```
